"""
Open WebUI Tools Package.

This package contains built-in tools that are automatically available
when native function calling is enabled.
"""
