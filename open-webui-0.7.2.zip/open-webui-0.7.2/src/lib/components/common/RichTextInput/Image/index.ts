import { Image } from './image.js';

export * from './image.js';

export default Image;
